# L8cpu

4 registers
256 bytes of memory
